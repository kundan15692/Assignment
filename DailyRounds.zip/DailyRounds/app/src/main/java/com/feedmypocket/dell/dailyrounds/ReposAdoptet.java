package com.feedmypocket.dell.dailyrounds;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ReposAdoptet extends RecyclerView.Adapter<ReposAdoptet.MyViewHolder>{

    List<MyRepositoriess> myRepositories = new ArrayList<>();
    Context context;
    public ReposAdoptet(Context context1, List<MyRepositoriess> repositorlist) {
        this.context = context1;
        this.myRepositories=repositorlist;
    }


    @Override
    public ReposAdoptet.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.repositories, parent, false);
        ReposAdoptet.MyViewHolder vh = new ReposAdoptet.MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull ReposAdoptet.MyViewHolder myViewHolder, int i) {

        myViewHolder.name.setText(""+myRepositories.get(i).getName());
        myViewHolder.full_name.setText(""+myRepositories.get(i).getFullName());
        myViewHolder.description.setText(""+myRepositories.get(i).getDescription());
        myViewHolder.created_at.setText("Created At "+myRepositories.get(i).getCreatedAt());
        myViewHolder.updated_at.setText("Updated At "+myRepositories.get(i).getUpdatedAt());
        myViewHolder.watchers.setText("Watchers "+myRepositories.get(i).getWatchers());
        myViewHolder.language.setText(""+myRepositories.get(i).getLanguage());

    }

    @Override
    public int getItemCount() {
        return myRepositories.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name,full_name,description,created_at,updated_at,watchers,language;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name = (TextView)itemView.findViewById(R.id.name);
            full_name = (TextView)itemView.findViewById(R.id.full_name);
            description = (TextView)itemView.findViewById(R.id.description);
            created_at = (TextView)itemView.findViewById(R.id.created_at);
            updated_at = (TextView)itemView.findViewById(R.id.updated_at);
            watchers = (TextView)itemView.findViewById(R.id.watchers);
            language = (TextView)itemView.findViewById(R.id.language);
        }
    }
}
