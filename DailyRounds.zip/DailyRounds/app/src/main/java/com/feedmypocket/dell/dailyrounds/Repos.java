package com.feedmypocket.dell.dailyrounds;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Repos extends AppCompatActivity {

    List<MyRepositoriess> myRepositories = new ArrayList<>();
    ReposAdoptet reposAdopter;
    RecyclerView repositorylist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repos);

        repositorylist = (RecyclerView)findViewById(R.id.repositorylist);
        Intent intent = getIntent();
        String userid = intent.getStringExtra("userid");
        getSupportActionBar().setTitle(Html.fromHtml("<font color='#ffffff'>"+userid+"</font>"));
        MyRespo(userid);
    }

    public void MyRespo(String userid) {

        final ProgressDialog progressDialog = new ProgressDialog(Repos.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please Wait");
        progressDialog.show();

        (Api.getClient().getMyRepos(userid)).enqueue(new Callback<List<MyRepositoriess>>() {
            @Override
            public void onResponse(Call<List<MyRepositoriess>> call, Response<List<MyRepositoriess>> response) {

                myRepositories.addAll(response.body());
                LoadAdopter();
                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<List<MyRepositoriess>> call, Throwable t) {
                Log.e("Failur response", t.toString());
                progressDialog.dismiss();

            }
        });
    }

    public void LoadAdopter(){

        reposAdopter = new ReposAdoptet(Repos.this,  myRepositories);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(Repos.this);
        repositorylist.setLayoutManager(linearLayoutManager);
        repositorylist.setAdapter(reposAdopter);

    }
}
