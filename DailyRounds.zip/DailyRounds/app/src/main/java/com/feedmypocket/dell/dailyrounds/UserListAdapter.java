package com.feedmypocket.dell.dailyrounds;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class UserListAdapter extends RecyclerView.Adapter<UserListAdapter.MyViewHolder>{

    List<Item> userLists = new ArrayList<>();
    Context context;
    public UserListAdapter(Context context1, List<Item> userlist) {
        this.context = context1;
        this.userLists=userlist;
    }


    @Override
    public UserListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.userrows, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull UserListAdapter.MyViewHolder myViewHolder, int i) {

        Picasso.get()
                .load(userLists.get(i).getAvatarUrl())
                .into(myViewHolder.profileimg);
        myViewHolder.username.setText(""+userLists.get(i).getLogin());
        myViewHolder.userid.setText(""+userLists.get(i).getId());
        final String s = ""+userLists.get(i).getLogin();
        myViewHolder.usertab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context,Repos.class);
                i.putExtra("userid",s);
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return userLists.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView profileimg;
        TextView username;
        TextView userid;
        CardView usertab;
        public MyViewHolder(@NonNull View itemView) {

            super(itemView);
            profileimg = (ImageView)itemView.findViewById(R.id.profileimg);
            username = (TextView) itemView.findViewById(R.id.username);
            userid = (TextView)itemView.findViewById(R.id.userid);
            usertab = (CardView)itemView.findViewById(R.id.card_view);
        }
    }
}
